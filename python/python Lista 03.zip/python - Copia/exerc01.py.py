# este programa soma dois numeros

# Entrada
numero1 = int(input('digite o primeiro numero'))
numero2 = int(input('digite o sugundo numero'))
# processamento
resultado = numero1 + numero2

# saida

print('a soma foi ', resultado)
