#entrada
d = int(input('qunados dias o carro foi alugado'))
km = int(input('quandos km o carro alugado percorreu'))
pagar = int
#processamento

pagar = d * 60 + km + 0,15

#saida
print('voce teve pagar',pagar)
