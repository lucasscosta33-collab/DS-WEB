# este programa coverte  metros e o exiba convertido em milímetros.

# Entrada
metros = (input('digite em metros'))
#processamento
resultado = metros *1000
#saida
print(resultado, "milímetros')


