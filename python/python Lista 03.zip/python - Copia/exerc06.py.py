#entrada

distancia = int(input("qual e a distancia" ))

velocidademedia = int(input("qual e a velocidade media" ))

tempo = int                      

#processamento
tempo = distancia / velocidademedia

#saida
print(" o tempo de viagem foi ",tempo)
        
