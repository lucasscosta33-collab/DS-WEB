#entrada
preço inp(int("qual e o preço"))
porcentualdedesconto input(int("percentual de desconto"))
#processamento
preço a pagar = (preço - porcentualdedesconto) /100 *100
#saida
print(preçoapagar,porcentualdedesconto)
