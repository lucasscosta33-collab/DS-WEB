#entada
c = int(input('queal e a temperatura em °c'))
f = int
#processamento
f = 9 / 5 * c + 32
#saida
print('a temperatura em °f e',f)
