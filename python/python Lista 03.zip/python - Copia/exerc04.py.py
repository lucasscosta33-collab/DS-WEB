#o aumento de um salário a porcentagem do aumento

# entrada
salario = int(input('qual e o seu salario'))
porcentagem = int(input('qual e a porcentagem de aumento'))
salarioatual = int
#procesamento

salarioatual = salario / 100 * porcentagem
#saida
print('o seu salario atual e ',salarioatual)
