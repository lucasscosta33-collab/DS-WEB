# esse programa
#Entrada
dias = int(input('quandos dias'))
horas = int(input('quandas horas'))
resultadodias = int

#processamento
resultadodia =  dias *24 * 60 * 60
resultadohoras = horas * 60 * 60
print('seu valor em seguntos e',resultadodia)
