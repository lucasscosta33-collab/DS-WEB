#entada

tv = int
qf = int(input('quandos voce fumou por dia'))
af= int(input('quandos anos voce fumou'))
#processamento
tv = qf * 365 * 10 /1440

#saida
print('voce perdeu',tv)

os.system('pause')
