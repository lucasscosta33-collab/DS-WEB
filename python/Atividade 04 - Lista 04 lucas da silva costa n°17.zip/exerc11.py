#aumento de salario

#entrada
salario = float(input('qual e o seu salario '))
#porecessamento
salarioatual = 10 / 100 * salario + salario 
if salario > 1250.00:
             print('o seu salario e',salarioatual)
             salarioatual2 = 15 / 100 * salario + salario
if salario < 1250.00:
    print('o seu salario e ',salarioatual)
    
