#entrada
velocidade = int(input(' qual foi a velocidade '))
km = int
multa = int
#processamendo
if velocidade > 80:
          multa = (velocidade - 80) * 5
          print('voce tem uma multa de ',multa)
else:
      velocidade < 80
      print('voce noa tem uma multa')
