n = 1
media = 0
while n <= 5:
 num = float(input("Digite o %f número: " % n))
 media = media + num / 5
 n = n + 1
print("media: %d" % media)
 
